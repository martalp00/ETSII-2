package sensores;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;
import org.junit.*;

public class SensorTest {
	GestorSensores gestor;

	@Before
	public void init() {
		gestor = new GestorSensores();
	}
	
	@After
	public void terminate() {
		gestor = null;
	}

	@Test
	public void inicialmenteElNumeroDeSensoresDelGestorEsCero() {
		fail("Implemente este caso de prueba");
	}

	@Test
	public void siSeBorraUnSensorNoExistenteSeElevaExcepcion() {
		fail("Implemente este caso de prueba");
	}

	@Test
	public void siSeObtieneLaTemperaturaMediaEnUnGestorVacioSeElevaExcepcion() {
		fail("Implemente este caso de prueba");
	}

	// el numero maximo de sensores permitido es 100
	@Test
	public void siSeIntroduceUnSensorEnUnGestorLlenoSeElevaExcepcion() {
		fail("Implemente este caso de prueba");
	}

	@Test
	public void siSeBorraUnSensorDelGestorSeDecrementaEnUnoElNumeroDeSensores() {
		ISensorTemperatura sensor1 = mock(ISensorTemperatura.class);
		when(sensor1.getNombre()).thenReturn("sensor1");
		gestor.introducirSensor(sensor1);

		int numSensores = gestor.getNumeroSensores();
		gestor.borrarSensor("sensor1");
		assertEquals(gestor.getNumeroSensores(), numSensores-1);
	}

	// se considera temperatura fuera de rango si la temperatura es menor que -90 o
	// mayor que 60
	@Test
	public void siAlgunSensorTieneTemperaturaFueraDeRangoObtenerLaTemperaturaMediaElevaUnaExcepcion() {
		fail("Implemente este caso de prueba");
	}

	// prueba con tres valores a tu eleccion
	@Test
	public void laTemperaturaMediaDeTresSensoresObtenidaATravesDelGestorEsCorrecta() {
		fail("Implemente este caso de prueba");
	}

	@Test
	public void siSeContactaTresVecesConSensoresDisponiblesNoSeBorraNinguno() {
		fail("Implemente este caso de prueba");
	}

	@Test
	public void siSeContactaTresVecesConUnSensorNoDisponibleSeBorraDelGestor() {
		fail("Implemente este caso de prueba");
	}
}
