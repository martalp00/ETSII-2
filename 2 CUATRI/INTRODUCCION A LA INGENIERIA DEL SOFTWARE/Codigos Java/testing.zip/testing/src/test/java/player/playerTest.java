package player;

import static org.junit.Assert.*;

import org.junit.*;

public class playerTest {
	private static final int VIDASMAX = 3;
	private static final int BALASMAX = 5;
	private static final int TAMINVENTARIO = 3;
	private Player jugador;

	@Before
	public void setUp() throws Exception {
		jugador = new Player(VIDASMAX, BALASMAX, TAMINVENTARIO);
	}

	@After
	public void tearDown() throws Exception {
		jugador = null;
	}
	
	// al inicio el n�mero de vidas es VIDASMAX
	@Test
	public void vidasIniciales() {
		assertEquals("Al crear las vidas son " + VIDASMAX, VIDASMAX, jugador.getVidas());
	}
	
	// al inicio el n�mero de balas es BALAMAX
	@Test
	public void balasIniciales() {
		
	}
	
	// al incio el inventario est� vac�o
	@Test
	public void inventarioInicial() {
		
	}
	
	// tras recibir da�o la vida disminuye el da�o
	@Test
	public void vidaDisminuyeTrasDa�o() {
		
	}
	
	// la vida nunca es menor que cero
	@Test
	public void vidaNuncaMenorCero() {
		
	}
	
	// si ha recibido tanto da�o como vidasmax est� muerto
	@Test
	public void masDa�oQueVidamaxEntoncesMuerto() {

	}
	
	// la vida aumenta al cursarse la cantidad indicada (si ha recibido da�o)
	@Test
	public void vidaAumentaAlCurar() throws MuertoException {
		int da�o = 1;
		jugador.herir(da�o);
		int vidaActual = jugador.getVidas();
		int cura = 1;
		jugador.curar(cura);
		assertTrue("Vidas aumentan al curar", jugador.getVidas() == vidaActual + cura);
	}
	
	// la vida nunca supera VIDASMAX
	@Test
	public void vidaNoSuperaVIDASMAX() {
		
	}	
	
	// no es posible revivir si ya el jugador est� vivo
	@Test(expected = VivoException.class)
	public void noRevivirSiEstaVivo() throws MuertoException, VivoException {
		jugador.revivir();
	}
	
	// no es posible herir a un muerto
	@Test
	public void noPodemosHerirAMuerto() {
		
	}
	
	// al revivir la vida es VIDASMAX
	@Test
	public void alRevivirVidaEsVIDASMAX() {
		
	}
	
	
	// TESTING DISPAROS
	
	// tras disparar las balas disminuyen en uno
	@Test
	public void dispararDisminuyeBalasEnUno() {
		
	}
	
	// tras recargar las balas son BALASMAX
	@Test
	public void trasRecargarBalasSonBALASMAX() {
		
	}
	
	// no es posible disparar sin balas
	@Test
	public void noPuedeDispararSinBalas() {
		
	}
	
	// un muerto no puede disparar
	@Test
	public void unMuertoNoPuedeDisparar() {
		
	}
	
	
	// TESTING INVENTARIO
	
	// tras a�adir un objeto al inventario, el inventario lo contiene
	@Test
	public void trasA�adirObjetoElInventarioLoContiene() throws InventarioLlenoException, MuertoException, ObjetoEnInventarioException {
		Integer item = Integer.valueOf(1);
		jugador.coger(item);
		assertTrue("El objeto est� en inventario", jugador.enInventario(item));
	}
	
	// tras a�adir un objeto al inventario, el inventario tiene tama�o 1
	@Test
	public void trasA�adirObjetoElInventarioTieneUnObjeto() {
		
	}
	
	// tras a�adir un objeto al inventario, el inventario tiene TAMINVENTARIO - 1
	@Test
	public void trasA�adirObjetoElInventarioTieneTama�oMenosUno() {
		
	}
	
	
	// tras a�adir un objeto al inventario y quitarlo, el inventario NO lo contiene
	@Test
	public void trasA�adirObjetoYQuitarloElInventarioNOLoContiene() {
		
	}
	
	// no podemos coger dos veces el mismo objeto
	@Test(expected = ObjetoEnInventarioException.class)
	public void NoPodemosCogerElMismoObjetoDosVeces() {
		
	}
	
	// no es posible soltar un objeto que no hemos cogido
	@Test
	public void NoPodemosSoltarUnObjetoNoCogido() {
		
	}
	
	// el inventario no puede contener mas de TAMINVENTARIO objetos
	@Test
	public void inventarioSeLlenaSiInsertamosObjeto() {
		
	}
	
	// el inventario no puede contener mas de TAMINVENTARIO objetos
	@Test
	public void inventarioNoPuedeTenerMasObjetoQueSuTama�o() {
		
	}
	
	// si el jugador est� muerto no puede coger objetos
	@Test
	public void unMuertoNoPuedeCogerObjeto() {
		
	}
	
	// si el jugador est� muerto no puede soltar objetos
	@Test
	public void unMuertoNoPuedeSoltarObjeto() {
		
	}
	
	// tras revivir el inventario est� vac�o
	@Test
	public void trasRevivirElInvetarioEstaVacio() {
		
	}
	
}
