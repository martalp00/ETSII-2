package player;

public class InventarioLlenoException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InventarioLlenoException(String msg) {
		super(msg);
	}
}
