package player;

public class SinBalasException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SinBalasException(String msg) {
		super(msg);
	}
}
