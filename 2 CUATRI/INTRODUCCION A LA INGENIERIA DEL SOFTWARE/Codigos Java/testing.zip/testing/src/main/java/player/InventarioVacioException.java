package player;

public class InventarioVacioException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InventarioVacioException(String msg) {
		super(msg);
	}
}
