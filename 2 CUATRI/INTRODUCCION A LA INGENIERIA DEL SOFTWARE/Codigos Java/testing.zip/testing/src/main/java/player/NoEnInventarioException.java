package player;

public class NoEnInventarioException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoEnInventarioException(String msg) {
		super(msg);
	}
}
