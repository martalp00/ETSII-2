package player;

public class ObjetoEnInventarioException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ObjetoEnInventarioException(String msg) {
		super(msg);
	}
}
