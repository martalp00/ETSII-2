package barcoMON;

import java.util.Arrays;
import java.util.concurrent.*;

public class Meta 
{
	private int  N;
	private int[] ganados;
	
	public Meta(int numVeleros){
		N = numVeleros;//Numero de veleros que participan en las regatas
		ganados = new int[N];
		for (int i=0; i<ganados.length; i++)
			ganados[i] = 0;//regatas que ha ganado cada velero
	}
	
	/*
	 * El velero id espera a que se pueda empezar la siguiente regata.
	 * El velero id indica que esta listo para la siguiente 
	 * regata y espera a que el arbitro de la salida.
	 */
	public  void esperaSalida(int id) throws InterruptedException{
		//TODO
		System.out.println("El velero "+id+" esta listo para salir");
		
	}
	
	/*
	 * El velero id ha llegado a la meta. El ganador actualiza el array
	 * ganados.
	 * 
	 */
	public  void finalCarrera(int id) throws InterruptedException{
		//TODO
		System.out.println("El velero "+id+" ha llegado a la meta");
		//si el velero id ha ganado se actualiza ganados[id]
	}
	/*
	 * El arbitro espera hasta que todos los veleros esten listos para
	 * salir. A continuacion, indica a todos que empieza la regata.
	 */
	public  void esperoTodosListos() throws InterruptedException{
		//TODO
		System.out.println("Empieza la carrera!!!!");
		
		
	}
	/*
	 * El arbitro espera que hayan llegado todos los veleros. 
	 * A continuacion, les informa de que pueden hacer otra carrera.
	 */
	public  void esperoTodosTerminan() throws InterruptedException{
		//TODO
		System.out.println("Todos han terminado!!!!");
	
		
	}
	
	public void resultados(){
		System.out.println("Resultados "+Arrays.toString(ganados));
	}

}
