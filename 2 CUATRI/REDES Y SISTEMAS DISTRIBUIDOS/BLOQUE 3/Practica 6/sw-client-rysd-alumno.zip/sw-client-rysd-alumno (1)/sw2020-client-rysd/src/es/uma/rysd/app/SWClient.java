package es.uma.rysd.app;

import javax.net.ssl.HttpsURLConnection;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import com.google.gson.Gson;

import es.uma.rysd.entities.*;

public class SWClient {
	// TODO: Complete el nombre de la aplicaci�n
    private final String app_name = "";
    
    private final String url_api = "https://swapi.dev/api/";

    // M�todos auxiliares facilitados
    
    // Obtiene la URL del recurso id del tipo resource
	public String generateEndpoint(String resource, Integer id){
		return url_api + resource + "/" + id + "/";
	}
	
	// Dada una URL de un recurso obtiene su ID
	public Integer getIDFromURL(String url){
		String[] parts = url.split("/");

		return Integer.parseInt(parts[parts.length-1]);
	}
	
	// Consulta un recurso y devuelve cu�ntos elementos tiene
	public int getNumberOfResources(String resource){    	
		// TODO: Trate de forma adecuada las posibles excepciones que pueden producirse
		
    	// TODO: Cree la URL correspondiente: https://swapi.dev/api/{recurso}/ reemplazando el recurso por el par�metro 
    	
    	// TODO: Cree la conexi�n a partir de la URL
    	
    	// TODO: A�ada las cabeceras User-Agent y Accept (vea el enunciado)
    	
    	// TODO: Indique que es una petici�n GET
    	
    	// TODO: Compruebe que el c�digo recibido en la respuesta es correcto
    	
    	// TODO: Deserialice la respuesta a CountResponse
        Gson parser = new Gson();
        InputStream in = null; // TODO: Obtenga el InputStream de la conexi�n
        CountResponse c = parser.fromJson(new InputStreamReader(in), CountResponse.class);
        // TODO: Devuelva el n�mero de elementos
        return 0;
	}
	
	public People getPerson(String urlname) {
    	People p = null;
    	// Por si acaso viene como http la pasamos a https
    	urlname = urlname.replaceAll("http:", "https:");

    	// TODO: Trate de forma adecuada las posibles excepciones que pueden producirse
		    	
    	// TODO: Cree la conexi�n a partir de la URL recibida
    	
    	// TODO: A�ada las cabeceras User-Agent y Accept (vea el enunciado)
    	
    	// TODO: Indique que es una petici�n GET
    	
    	// TODO: Compruebe que el c�digo recibido en la respuesta es correcto
    	
    	// TODO: Deserialice la respuesta a People
    	
        // TODO: Para las preguntas 2 y 3 (no necesita completar esto para la pregunta 1)
    	// TODO: A partir de la URL en el campo homreworld obtenga los datos del planeta y almac�nelo en atributo homeplanet

    	return p;
	}

	public Planet getPlanet(String urlname) {
    	Planet p = null;
    	// Por si acaso viene como http la pasamos a https
    	urlname = urlname.replaceAll("http:", "https:");

    	// TODO: Trate de forma adecuada las posibles excepciones que pueden producirse
		    	
    	// TODO: Cree la conexi�n a partir de la URL recibida
    	
    	// TODO: A�ada las cabeceras User-Agent y Accept (vea el enunciado)
    	
    	// TODO: Indique que es una petici�n GET
    	
    	// TODO: Compruebe que el c�digo recibido en la respuesta es correcto
    	
    	// TODO: Deserialice la respuesta a Planet
    	
        return p;
	}

	public People search(String name){
    	People p = null;
    	// TODO: Trate de forma adecuada las posibles excepciones que pueden producirse
		    	
    	// TODO: Cree la conexi�n a partir de la URL (url_api + name tratado - vea el enunciado)
    	
    	// TODO: A�ada las cabeceras User-Agent y Accept (vea el enunciado)
    	
    	// TODO: Indique que es una petici�n GET
    	
    	// TODO: Compruebe que el c�digo recibido en la respuesta es correcto
    	
    	// TODO: Deserialice la respuesta a SearchResponse -> Use la primera posici�n del array como resultado
    	
        // TODO: Para las preguntas 2 y 3 (no necesita completar esto para la pregunta 1)
    	// TODO: A partir de la URL en el campo homreworld obtenga los datos del planeta y almac�nelo en atributo homeplanet

        return p;
    }

}
