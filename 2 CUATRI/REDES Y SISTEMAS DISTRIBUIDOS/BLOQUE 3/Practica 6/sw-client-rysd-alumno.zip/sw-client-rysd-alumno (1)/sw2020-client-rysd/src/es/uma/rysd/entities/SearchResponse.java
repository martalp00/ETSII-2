package es.uma.rysd.entities;

//Clase obtenida cuando se busca por el nombre de una persona que potencialmente puede devolver muchas (o ninguna)

public class SearchResponse {
	public Integer count;
	public People[] results;
	
}
