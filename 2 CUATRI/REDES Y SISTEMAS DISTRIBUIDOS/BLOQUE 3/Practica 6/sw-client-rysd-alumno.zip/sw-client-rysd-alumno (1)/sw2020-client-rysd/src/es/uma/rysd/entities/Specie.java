package es.uma.rysd.entities;

//Clase obtenida cuando se consulta por una especie

public class Specie {
	public String name;
	public String language;
	public String designation;
	public String[] people;
}
