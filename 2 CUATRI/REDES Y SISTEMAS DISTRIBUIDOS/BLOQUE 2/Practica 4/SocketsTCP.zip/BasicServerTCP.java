import java.io.*;
import java.net.*;

class BasicServerTCP {

    public static void main(String[] args) throws IOException
    {
        
        try
        {
        	ServerSocket server = new ServerSocket(12345,10);
        	Socket client = server.accept();
            
        	BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            PrintWriter out = new PrintWriter(client.getOutputStream(), true);
                
            System.out.println("Mensaje del cliente: " + in.readLine());
            out.println("Respuesta del servidor");
                
            in.close();
            out.close();
            client.close();
        }
        catch (Exception e)
        {
            System.out.println("Error");
            System.exit(-1);
        }
    }
    
}

