


public abstract class Mochila {

	public abstract SolucionMochila resolver(ProblemaMochila pm) ;	

}
