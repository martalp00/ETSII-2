

/**
 * 
 * @author ***** Jose A. Onieva *******
 *
 */
public class MochilaPD extends Mochila {
	
	public SolucionMochila resolver(ProblemaMochila pm) {
		SolucionMochila sm=null;
		// A resolver por el alumno
		return sm;
	}
}
