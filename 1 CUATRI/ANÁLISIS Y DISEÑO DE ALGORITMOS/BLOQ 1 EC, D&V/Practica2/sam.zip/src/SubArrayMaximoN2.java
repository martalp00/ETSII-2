/**
 * 
 * @author ***** Indicar aqui el autor de la practica *******
 *
 */
public class SubArrayMaximoN2 extends SubArrayMaximo {

	public SolucionSubArrayMaximo resolver(int[] array) {
		SolucionSubArrayMaximo ssam = new SolucionSubArrayMaximo();
		 /** Implementar aqui una solucion por fuerza bruta */
		return ssam;
	}
	
}
