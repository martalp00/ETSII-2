-------------------------------------------------------------------------------
-- Heap sort demo
--
-- Data Structures. Grado en Informática. UMA.
-- Pepe Gallardo, 2012
-------------------------------------------------------------------------------

module Demos.Heap.HeapSortDemo where

import DataStructures.Heap.HeapSort(heapSort)

demo = heapSort [1,7,2,3,0,9]
