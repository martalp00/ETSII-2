-------------------------------------------------------------------------------
-- Ford-Fulkerson Algorithm. Maximal flow for a weighted directed graph.
--
-- Student's name:
-- Student's group:
--
-- Data Structures. Grado en Informática. UMA.
-------------------------------------------------------------------------------

module DataStructures.Graph.FordFulkerson where

import Data.List  ((\\))
import DataStructures.Graph.WeightedDiGraph
import DataStructures.Graph.WeightedDiGraphBFT

maxFlowPath :: Path (WDiEdge a Integer) -> Integer
maxFlowPath path@(edge@(E _ w _):ys) = min w ys
 where
  min w [] = w
  min w ((E _ w1 _):ys)
   | w1 < w = min w1 ys
   | otherwise = min w ys

updateEdge ::(Eq a) => a -> a -> Integer -> [WDiEdge a Integer] -> [WDiEdge a Integer]
updateEdge x y p edges = (update False edges [])
 where
  update False [] lista = [(E x p y)]++lista
  update True [] lista = lista
  update found (edge@(E src wgth dst):ys) lista
   | (x == src) && (y == dst) && (p+wgth /= 0) = update True ys [(E x (p+wgth) y)]++lista
   | (x == src) && (y == dst) && (p+wgth == 0) = update True ys lista
   | otherwise = update (found||False) ys [(E src wgth dst)]++lista

updateEdges :: (Eq a) => Path (WDiEdge a Integer) -> Integer -> [WDiEdge a Integer] -> [WDiEdge a Integer]
updateEdges [] p edges = edges
updateEdges path@((E x _ y):ys) p edges = updateEdges ys p (updateEdge x y p edges)

addFlow :: (Eq a) => a -> a -> Integer -> [WDiEdge a Integer] -> [WDiEdge a Integer]
addFlow x y p sol = (flow False sol [])
 where
  flow False [] lista = [E x p y]++lista
  flow True [] lista = lista
  flow found ((E src w dst):ys) lista
   | (x == src) && (y == dst) = flow True ys [E src (w+p) dst]++lista
   | (y == src) && (x == dst) && (p == w) = flow True ys lista
   | (y == src) && (x == dst) && (w < p) = flow True ys [E src (p-w) dst]++lista
   | (y == src) && (x == dst) && (w > p) = flow True ys [E dst (w-p) src]++lista
   | otherwise = flow (found || False) ys [E src w dst]++lista

addFlows :: (Eq a) => Path (WDiEdge a Integer) -> Integer -> [WDiEdge a Integer] -> [WDiEdge a Integer]
addFlows [] p sol = sol
addFlows ((E src _ dst):ys) p sol = addFlows ys p (addFlow src dst p sol)

fordFulkerson :: (Ord a) => (WeightedDiGraph a Integer) -> a -> a -> [WDiEdge a Integer]
fordFulkerson g src dst = fF path edges []
 where
  path = bftPathTo g src dst
  edges = weightedDiEdges g
  fF Nothing _ sol = sol
  fF (Just pth) edges sol = fF path' edges' sol'
   where
    mf = maxFlowPath pth
    edgesAux = updateEdges pth (-mf) edges
    pathInverted = (aux pth [])
     where
      aux [] pathInv = pathInv
      aux ((E x p y):ys) pathInv = aux ys [E y p x]++pathInv
    edges' = updateEdges pathInverted mf edgesAux
    wdg = mkWeightedDiGraphEdges (vertices g) edges'
    sol' = addFlows pth mf sol
    path' = bftPathTo wdg src dst

maxFlow :: (Ord a) => [WDiEdge a Integer] -> a -> Integer
maxFlow sol src = mF sol 0
 where
  mF [] suma = suma
  mF ((E x w _):ys) suma
   | x == src = mF ys (suma + w)
   | otherwise = mF ys suma

maxFlowMinCut :: (Ord a) => (WeightedDiGraph a Integer) -> a -> a -> [a] -> Integer
maxFlowMinCut g src dst set = aux sol 0
 where
  sol = fordFulkerson g src dst
  aux [] suma = suma
  aux ((E x w y):ys) suma
   | (src `elem` set) && (x `elem` set) && not(y `elem` set) = aux ys (w+suma)
   | (src `elem` set) && (y `elem` set) && not(x `elem` set) = aux ys (suma-w)
   | (dst `elem` set) && (x `elem` set) && not(y `elem` set) = aux ys (suma-w)
   | (dst `elem` set) && (y `elem` set) && not(x `elem` set) = aux ys (w+suma)
   | otherwise = aux ys suma


-- A partir de aquí hasta el final
-- SOLO para alumnos a tiempo parcial 
-- sin evaluación continua

localEquilibrium :: (Ord a) => WeightedDiGraph a Integer -> a -> a -> Bool
localEquilibrium = undefined

sourcesAndSinks :: (Eq a) => WeightedDiGraph a b -> ([a],[a])
sourcesAndSinks = undefined

unifySourceAndSink :: (Eq a) => WeightedDiGraph a Integer -> a -> a -> WeightedDiGraph a Integer
unifySourceAndSink = undefined
