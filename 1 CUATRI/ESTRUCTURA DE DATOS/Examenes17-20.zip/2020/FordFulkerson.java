/*
  Student's name:

  Student's group:
*/

package dataStructures.graph;

import dataStructures.list.LinkedList;
import dataStructures.list.List;
import dataStructures.set.HashSet;
import dataStructures.set.Set;
import dataStructures.tuple.Tuple2;


import java.util.Iterator;

public class FordFulkerson<V> {
    private WeightedDiGraph<V,Integer> g; // Initial graph 
    private List<WDiEdge<V,Integer>> sol; // List of edges representing maximal flow graph
    private V src; 			  // Source
    private V dst; 		  	  // Sink
	
    /**
     * Constructors and methods
     */

    public static <V> int maxFlowPath(List<WDiEdge<V,Integer>> path) {
        Iterator<WDiEdge<V, Integer>> it = path.iterator();
        int mf = it.next().getWeight();
        WDiEdge<V, Integer> next;

        while (it.hasNext()) {
            next = it.next();
            if (mf > next.getWeight()) mf = next.getWeight();
        }

        return mf;
    }

    public static <V> List<WDiEdge<V,Integer>> updateEdge(V x, V y, Integer p, List<WDiEdge<V,Integer>> edges) {
        Iterator<WDiEdge<V, Integer>> it = edges.iterator();
        List<WDiEdge<V, Integer>> nueva = new LinkedList<>();
        WDiEdge<V, Integer> edge;
        boolean found = false;

        while (it.hasNext()) {
            edge = it.next();
            if (edge.getSrc().equals(x) && edge.getDst().equals(y)) {
                if (edge.getWeight()+p > 0) nueva.append(new WDiEdge<>(x, edge.getWeight()+p, y));
                found = true;
            } else nueva.append(edge);
        }
        if (!found) nueva.append(new WDiEdge<>(x, p, y));

        return nueva;
    }

    public static <V> List<WDiEdge<V,Integer>> updateEdges(List<WDiEdge<V,Integer>> path, Integer p, List<WDiEdge<V,Integer>> edges) {
        for (WDiEdge<V, Integer> edge : path) {
            edges = updateEdge(edge.getSrc(), edge.getDst(), p, edges);
        }

        return edges;
    }

    public static <V> List<WDiEdge<V,Integer>> addFlow(V x, V y, Integer p, List<WDiEdge<V,Integer>> sol) {
        boolean found = false;
        Iterator<WDiEdge<V, Integer>> it = sol.iterator();
        WDiEdge<V, Integer> edge = null;

        while (!found && it.hasNext()) {
            edge = it.next();
            if ((edge.getSrc().equals(x) && edge.getDst().equals(y)) ||
                    (edge.getSrc().equals(y) && edge.getDst().equals(x))) found = true;
        }

        if (found) {
            if (x.equals(edge.getSrc())) sol = updateEdge(x, y, p, sol);
            else if (edge.getWeight().equals(p)) sol = updateEdge(x, y, -p, sol);
            else if (edge.getWeight().compareTo(p) < 0) sol = updateEdge(x, y, p-edge.getWeight(), sol);
            else {
                sol = updateEdge(x, y, -edge.getWeight(), sol);
                sol = updateEdge(y, x, edge.getWeight()-p, sol);
            }
        } else {
            sol.append(new WDiEdge<>(x, p, y));
        }

        return sol;
    }

    public static <V> List<WDiEdge<V,Integer>> addFlows(List<WDiEdge<V,Integer>> path, Integer p, List<WDiEdge<V,Integer>> sol) {
        for (WDiEdge<V, Integer> edge : path) {
            sol = addFlow(edge.getSrc(), edge.getDst(), p, sol);
        }
        return sol;
    }

    public FordFulkerson(WeightedDiGraph<V,Integer> g, V src, V dst) {
        // Variables
        this.g = g;
        int mf;
        List<WDiEdge<V, Integer>> edges;
        List<WDiEdge<V, Integer>> pathInverted;

        // Lista sol inicial
        sol = new LinkedList<>();

        // Path
        List<WDiEdge<V, Integer>> path = new WeightedBreadthFirstTraversal<>(g, src).pathTo(dst);
        while (path != null) {
            mf = maxFlowPath(path);
            edges = g.wDiEdges();
            edges = updateEdges(path, -mf, edges);
            pathInverted = new LinkedList<>();
            for (WDiEdge<V, Integer> edge : path) {
                pathInverted.append(new WDiEdge<>(edge.getDst(), edge.getWeight(), edge.getSrc()));
            }
            edges = updateEdges(pathInverted, mf, edges);
            g = new WeightedDictionaryDiGraph<>(g.vertices(), edges);
            sol = addFlows(path, mf, sol);

            path = new WeightedBreadthFirstTraversal<>(g, src).pathTo(dst);
        }
        this.src = src;
        this.dst = dst;
    }

    public int maxFlow() {
        int mf = 0;
        Iterator<WDiEdge<V, Integer>> it = sol.iterator();
        WDiEdge<V, Integer> edge;
        while (it.hasNext()) {
            edge = it.next();
            if (edge.getSrc().equals(src)) mf += edge.getWeight();
        }

        return mf;
    }

    public int maxFlowMinCut(Set<V> set) {

        int mFMC = 0;
        Set<V> set1 = g.vertices();
        for (V v : set) {
            set1.delete(v);
        }

        for (WDiEdge<V, Integer> edge : getSolution()) {
            if (set.isElem(edge.getSrc()) && set1.isElem(edge.getDst())) mFMC += edge.getWeight();
            else if (set1.isElem(edge.getSrc()) && set.isElem(edge.getDst())) mFMC -= edge.getWeight();
        }

        return mFMC;
    }

    /**
     * Provided auxiliary methods
     */
    public List<WDiEdge<V, Integer>> getSolution() {
        return sol;
    }
	
    /**********************************************************************************
     * A partir de aquí SOLO para estudiantes a tiempo parcial sin evaluación continua.
     * ONLY for part time students.
     * ********************************************************************************/

    public static <V> boolean localEquilibrium(WeightedDiGraph<V,Integer> g, V src, V dst) {
        // TO DO
        return false;
    }
    public static <V,W> Tuple2<List<V>,List<V>> sourcesAndSinks(WeightedDiGraph<V,W> g) {
        // TO DO
        return null;
    }

    public static <V> void unifySourceAndSink(WeightedDiGraph<V,Integer> g, V newSrc, V newDst) {
        // TO DO
    }
}
