/******************************************************************************
 * Student's name:
 * Student's group:
 * Data Structures. Grado en Informática. UMA.
******************************************************************************/

package dataStructures.vector;


import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class SparseVector<T> implements Iterable<T> {

    protected interface Tree<T> {

        T get(int sz, int i);

        Tree<T> set(int sz, int i, T x);
    }

    // Unif Implementation

    protected static class Unif<T> implements Tree<T> {

        private T elem;

        public Unif(T e) {
            elem = e;
        }

        @Override
        public T get(int sz, int i) {
            return elem;
        }

        @Override
        public Tree<T> set(int sz, int i, T x) {
            Tree<T> t = this;
            if (elem != x) {
                if (sz > 1) {
                    Tree<T> izq = new Unif<>(elem);
                    Tree<T> dcha = new Unif<>(elem);
                    if (i >= sz/2) dcha = dcha.set(sz/2, i-sz/2, x);
                    else izq = izq.set(sz/2, i-sz/2, x);
                    t = new Node<>(izq, dcha);
                } else t = new Unif<>(x);
            }

            return t;
        }

        @Override
        public String toString() {
            return "Unif(" + elem + ")";
        }
    }

    // Node Implementation

    protected static class Node<T> implements Tree<T> {

        private Tree<T> left, right;

        public Node(Tree<T> l, Tree<T> r) {
            left = l;
            right = r;
        }

        @Override
        public T get(int sz, int i) {
            T elem;
            if (i>= sz/2){
                elem = right.get(sz/2, i-sz/2);
            }
            else elem = left.get(sz/2, i);
            
            return elem;
        }

        @Override
        public Tree<T> set(int sz, int i, T x) {
            Tree<T> t;
            if (sz == 1) t = new Unif<>(x);
            else if (sz == 2) {
                if (i == 0) t = new Node<>(new Unif<>(x), right);
                else t = new Node<>(left, new Unif<>(x));
            }
            else if (i >= sz/2) {
                if (right == null) right = new Node<>(null, null);
                right = right.set(sz/2, i-sz/2, x);
                t = new Node<>(left, right);
            } else {
                if (left == null) left = new Node<>(null, null);
                left = left.set(sz/2, i, x);
                t = new Node<>(left, right);
            }

            return t;
        }

        protected Tree<T> simplify() {
            Tree<T> t = this;
            if (left instanceof Unif && right instanceof Unif) {
                if (((Unif<T>) left).elem.equals(((Unif<T>) right).elem)) t = new Unif<>(((Unif<T>) left).elem);
            }
            return t;
        }

        @Override
        public String toString() {
            return "Node(" + left + ", " + right + ")";
        }
    }

    // SparseVector Implementation

    private int size;
    private Tree<T> root;

    public SparseVector(int n, T elem) {
        if (n < 0) throw new VectorException("n negativo");
        size = (int) Math.pow(2, n);

        root = new Node<>(null, null);
        for(int i = 0; i<size; i++) {
            root = root.set(size, i, elem);
        }
    }

    public int size() {
        return size;
    }

    public T get(int i) {
        if (i >= size) throw new VectorException("Indice inexistente");
        return root.get(size, i);
    }

    public void set(int i, T x) {
        if (i >= size) throw new VectorException("Indice inexistente");
        root.set(size, i, x);
    }

    @Override
    public Iterator<T> iterator() {
        List<T> l = new LinkedList<>();
        for (int i = 0; i<size; i++) {
            l.add(i, this.get(i));
        }

        return l.iterator();
    }

    @Override
    public String toString() {
        return "SparseVector(" + size + "," + root + ")";
    }
}
