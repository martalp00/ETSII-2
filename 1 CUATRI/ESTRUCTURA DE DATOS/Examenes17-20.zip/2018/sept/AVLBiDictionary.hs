-------------------------------------------------------------------------------
-- Apellidos, Nombre: Moret Yáñez, Nicolás 
-- Titulacion, Grupo: Ingenieria Informática, 2ºA
--
-- Estructuras de Datos. Grados en Informatica. UMA.
-------------------------------------------------------------------------------

module AVLBiDictionary( BiDictionary
                      , empty
                      , isEmpty
                      , size
                      , insert
                      , valueOf
                      , keyOf
                      , deleteByKey
                      , deleteByValue
                      , toBiDictionary
                      , compose
                      , isPermutation
                      , orbitOf
                      , cyclesOf
                      ) where

import qualified DataStructures.Dictionary.AVLDictionary as D
import qualified DataStructures.Set.BSTSet               as S

import           Data.List                               (intercalate, nub,
                                                          (\\))
import           Data.Maybe                              (fromJust, fromMaybe,
                                                          isJust)
import           Test.QuickCheck


data BiDictionary a b = Bi (D.Dictionary a b) (D.Dictionary b a)

-- | Exercise a. empty, isEmpty, size

empty :: (Ord a, Ord b) => BiDictionary a b
empty = Bi (D.empty) (D.empty)

isEmpty :: (Ord a, Ord b) => BiDictionary a b -> Bool
isEmpty bi@(Bi dica dicb) = dica == D.empty && dicb == D.empty

size :: (Ord a, Ord b) => BiDictionary a b -> Int
size bi@(Bi dica dicb) = D.size dica

-- | Exercise b. insert

insert :: (Ord a, Ord b) => a -> b -> BiDictionary a b -> BiDictionary a b
insert x y bi@(Bi dica dicb) = Bi (D.insert x y dica) (D.insert y x dicb)

-- | Exercise c. valueOf

valueOf :: (Ord a, Ord b) => a -> BiDictionary a b -> Maybe b
valueOf x bi@(Bi dica _) 
 | not (D.isDefinedAt x dica) = Nothing
 | otherwise = D.valueOf x dica

-- | Exercise d. keyOf

keyOf :: (Ord a, Ord b) => b -> BiDictionary a b -> Maybe a
keyOf y bi@(Bi _ dicb) 
 | not (D.isDefinedAt y dicb) = Nothing
 | otherwise =  D.valueOf y dicb

-- | Exercise e. deleteByKey

deleteByKey :: (Ord a, Ord b) => a -> BiDictionary a b -> BiDictionary a b
deleteByKey x bi@(Bi dica dicb)
 | not (D.isDefinedAt x dica) = bi
 | otherwise = Bi (D.delete x dica) (D.delete y dicb)
 where
  y = fromJust(D.valueOf x dica)

-- | Exercise f. deleteByValue

deleteByValue :: (Ord a, Ord b) => b -> BiDictionary a b -> BiDictionary a b
deleteByValue y bi@(Bi dica dicb) 
 | not (D.isDefinedAt y dicb) = bi
 | otherwise = Bi (D.delete x dica) (D.delete y dicb)
 where
  x = fromJust(D.valueOf y dicb)

-- | Exercise g. toBiDictionary

toBiDictionary :: (Ord a, Ord b) => D.Dictionary a b -> BiDictionary a b
toBiDictionary dica = Bi dica (invert (D.keysValues dica) D.empty)
 where
  invert [] dicb = dicb
  invert ((x, y):ys) dicb = invert ys (D.insert y x dicb)

-- | Exercise h. compose

compose :: (Ord a, Ord b, Ord c) => BiDictionary a b -> BiDictionary b c -> BiDictionary a c
compose bi1@(Bi dic1a dic1b) bi2@(Bi dic2a dic2b) = toBiDictionary dic
 where
  dic = aux (D.keysValues dic1a) D.empty
  aux [] dicx = dicx
  aux ((x,y):ys) dicx
   | not (D.isDefinedAt y dic2a) = aux ys dicx
   | otherwise = aux ys (D.insert x (fromJust(D.valueOf y dic2a)) dicx)

-- | Exercise i. isPermutation

isPermutation :: Ord a => BiDictionary a a -> Bool
isPermutation bi@(Bi dica dicb) = D.foldValues f True dica
 where
  f = (\x y -> y && (D.isDefinedAt x dica))


-- |------------------------------------------------------------------------


-- | Exercise j. orbitOf

orbitOf :: Ord a => a -> BiDictionary a a -> [a]
orbitOf x bi@(Bi dica dicb) = (aux x [x])
 where
  aux elem lista
   | fromJust(D.valueOf elem dica) == x = lista
   | otherwise = aux (fromJust(D.valueOf elem dica)) ([fromJust(D.valueOf elem dica)]++lista)

-- | Exercise k. cyclesOf

cyclesOf :: Ord a => BiDictionary a a -> [[a]]
cyclesOf bi@(Bi dica dicb) = (D.foldKeys func [] dica)
 where
  func = (\x y -> [orbitOf x bi] ++ y | D.delete x dica)

-- |------------------------------------------------------------------------


instance (Show a, Show b) => Show (BiDictionary a b) where
  show (Bi dk dv)  = "BiDictionary(" ++ intercalate "," (aux (D.keysValues dk)) ++ ")"
                        ++ "(" ++ intercalate "," (aux (D.keysValues dv)) ++ ")"
   where
    aux kvs  = map (\(k,v) -> show k ++ "->" ++ show v) kvs
