package dataStructures.dictionary;
import dataStructures.list.LinkedList;
import dataStructures.list.List;

import dataStructures.list.ArrayList;
import dataStructures.set.AVLSet;
import dataStructures.set.Set;
import dataStructures.tuple.Tuple2;

import java.util.Iterator;

/**
 * Estructuras de Datos. Grados en Informatica. UMA.
 * Examen de septiembre de 2018.
 *
 * Apellidos, Nombre:
 * Titulacion, Grupo:
 */
public class HashBiDictionary<K,V> implements BiDictionary<K,V>{
	private Dictionary<K,V> bKeys;
	private Dictionary<V,K> bValues;
	
	public HashBiDictionary() {
		bKeys = new HashDictionary<>();
		bValues = new HashDictionary<>();
	}
	
	public boolean isEmpty() {
		return bKeys.isEmpty() && bValues.isEmpty();
	}
	
	public int size() {
		return bKeys.size();
	}
	
	public void insert(K k, V v) {
		bKeys.insert(k, v);
		bValues.insert(v, k);
	}
	
	public V valueOf(K k) {
		return bKeys.valueOf(k);
	}
	
	public K keyOf(V v) {
		return bValues.valueOf(v);
	}
	
	public boolean isDefinedKeyAt(K k) {
		return bKeys.isDefinedAt(k);
	}
	
	public boolean isDefinedValueAt(V v) {
		return bValues.isDefinedAt(v);
	}
	
	public void deleteByKey(K k) {
		bValues.delete(bKeys.valueOf(k));
		bKeys.delete(k);
	}
	
	public void deleteByValue(V v) {
		bKeys.delete(bValues.valueOf(v));
		bValues.delete(v);
	}
	
	public Iterable<K> keys() {
		return bKeys.keys();
	}
	
	public Iterable<V> values() {
		return bValues.keys();
	}
	
	public Iterable<Tuple2<K, V>> keysValues() {
		return bKeys.keysValues();
	}
	
		
	public static <K,V extends Comparable<? super V>> BiDictionary<K, V> toBiDictionary(Dictionary<K,V> dict) {
		BiDictionary<K,V> hbd = new HashBiDictionary<>();
		for (Tuple2<K,V> tuple2 : dict.keysValues()) {
			if (!(hbd.isDefinedKeyAt(tuple2._1()) && hbd.isDefinedValueAt(tuple2._2()))) {
				hbd.insert(tuple2._1(), tuple2._2());
			}
			else throw new IllegalArgumentException();
		}
		return hbd;
	}
	
	public <W> BiDictionary<K, W> compose(BiDictionary<V,W> bdic) {
		BiDictionary<K,W> composed = new HashBiDictionary<>();
		for (Tuple2<K,V> tuple2 : bKeys.keysValues()) {
			if (bdic.isDefinedKeyAt(tuple2._2())){
				composed.insert(tuple2._1(), bdic.valueOf(tuple2._2()));
			}
		}

		return composed;
	}

	public static <K extends Comparable<? super K>> boolean isPermutation(BiDictionary<K,K> bd) {
		boolean perm = true;
		Iterator<K> it = bd.keys().iterator();
		K key;
		while (it.hasNext() && perm) {
			key = it.next();
			if (!bd.isDefinedValueAt(key)) perm = false;
		}

		return perm;
	}
	
	// Solo alumnos con evaluaci�n por examen final.
    // =====================================
	
	public static <K extends Comparable<? super K>> List<K> orbitOf(K k, BiDictionary<K,K> bd) {
		if (!isPermutation(bd)) throw new IllegalArgumentException();
		List<K> list = new LinkedList<>();
		K aux = k;
		do {
			aux = bd.valueOf(aux);
			list.append(aux);
		} while (aux != k);

		return list;
	}
	
	public static <K extends Comparable<? super K>> List<List<K>> cyclesOf(BiDictionary<K,K> bd) {
		if(!isPermutation(bd)) throw new IllegalArgumentException();
		List<List<K>> lists = new LinkedList<>();
		List<K> list;
		Iterator<K> it;
		Iterator<K> keys = bd.keys().iterator();
		while (keys.hasNext()) {
			list = orbitOf(keys.next(), bd);
			lists.append(list);
			it = list.iterator();
			while (it.hasNext()) {
				bd.deleteByKey(it.next());
			}
			keys = bd.keys().iterator();
		}

		return lists;
	}

    // =====================================
	
	
	@Override
	public String toString() {
		return "HashBiDictionary [bKeys=" + bKeys + ", bValues=" + bValues + "]";
	}
	
	
}
