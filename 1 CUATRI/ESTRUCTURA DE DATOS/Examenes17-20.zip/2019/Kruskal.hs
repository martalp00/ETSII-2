----------------------------------------------
-- Estructuras de Datos.  2018/19
-- 2º Curso del Grado en Ingeniería [Informática | del Software | de Computadores].
-- Escuela Técnica Superior de Ingeniería en Informática. UMA
--
-- Examen 4 de febrero de 2019
--
-- ALUMNO/NAME:
-- GRADO/STUDIES:
-- NÚM. MÁQUINA/MACHINE NUMBER:
--
----------------------------------------------

module Kruskal(kruskal, kruskals) where

import qualified DataStructures.Dictionary.AVLDictionary as D
import qualified DataStructures.PriorityQueue.LinearPriorityQueue as Q
import DataStructures.Graph.DictionaryWeightedGraph

kruskal :: (Ord a, Ord w) => WeightedGraph a w -> [WeightedEdge a w]
kruskal wg = (aux pq camino [])
 where
  pq = foldr (Q.enqueue) Q.empty (edges wg)
  camino = foldr (\x y -> D.insert x x y) D.empty (vertices wg)
  aux pq' camino' tree
   | Q.isEmpty pq' = tree
   | rep1 == rep2 = aux (Q.dequeue pq') camino' tree
   | otherwise = aux (Q.dequeue pq') (D.insert rep2 src camino') [first]++tree
      where
       rep1 = rep src camino'
       rep2 = rep dst camino'
       first@(WE src wgth dst) = Q.first pq'

rep :: (Ord a) => a -> D.Dictionary a a -> a
rep x dic
 | x == next = next
 | otherwise = rep next dic
    where
     Just next = D.valueOf x dic

-- Solo para evaluación continua / only for part time students
kruskals :: (Ord a, Ord w) => WeightedGraph a w -> [[WeightedEdge a w]]
kruskals = undefined
