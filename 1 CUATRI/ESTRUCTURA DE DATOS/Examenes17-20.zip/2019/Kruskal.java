/**----------------------------------------------
 * -- Estructuras de Datos.  2018/19
 * -- 2º Curso del Grado en Ingeniería [Informática | del Software | de Computadores].
 * -- Escuela Técnica Superior de Ingeniería en Informática. UMA
 * --
 * -- Examen 4 de febrero de 2019
 * --
 * -- ALUMNO/NAME:
 * -- GRADO/STUDIES:
 * -- NÚM. MÁQUINA/MACHINE NUMBER:
 * --
 * ----------------------------------------------
 */

import dataStructures.graph.DictionaryWeightedGraph;
import dataStructures.graph.WeightedGraph;
import dataStructures.graph.WeightedGraph.WeightedEdge;

import dataStructures.dictionary.Dictionary;
import dataStructures.dictionary.HashDictionary;
import dataStructures.priorityQueue.PriorityQueue;
import dataStructures.priorityQueue.LinkedPriorityQueue;
import dataStructures.set.Set;
import dataStructures.set.HashSet;
import dataStructures.tuple.Tuple2;

import java.util.Iterator;

public class Kruskal {
	public static <V,W> Set<WeightedEdge<V,W>> kruskal(WeightedGraph<V,W> g) {

		// Set inicial
		Dictionary<V, V> camino = new HashDictionary<>();
		for (V v : g.vertices()) camino.insert(v, v);

		// PQ
		Iterator<WeightedEdge<V, W>> it = g.edges().iterator();
		PriorityQueue<WeightedEdge<V, W>> pq = new LinkedPriorityQueue<>();
		while (it.hasNext()) pq.enqueue(it.next());

		// T (aristas seleccionadas)
		Set<WeightedEdge<V, W>> kruskal = new HashSet<>();

		// Ejecución
		WeightedEdge<V, W> edge;

		while (!pq.isEmpty()) {
			edge = pq.first();
			if (representante(edge.source(), camino) != representante(edge.destination(), camino)){
				kruskal.insert(edge);
				camino.insert(representante(edge.destination(), camino), edge.source());
			}
			pq.dequeue();
		}
		
		return kruskal;
	}

	private static <V> V representante(V v, Dictionary<V, V> camino) {

		while (v != camino.valueOf(v)) {
			v = camino.valueOf(v);
		}

		return v;
	}


	// Sólo para evaluación continua / only for part time students
	public static <V,W> Set<Set<WeightedEdge<V,W>>> kruskals(WeightedGraph<V,W> g) {

		// COMPLETAR
		
		return null;
	}
}
