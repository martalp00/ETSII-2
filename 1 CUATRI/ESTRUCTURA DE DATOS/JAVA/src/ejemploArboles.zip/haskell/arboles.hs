data TreeB a = EmptyB | NodeB (TreeB a) a (TreeB a) deriving Show

ejemplo:: TreeB Char
ejemplo = NodeB (NodeB (NodeB (NodeB EmptyB 's' EmptyB) 't' (NodeB EmptyB 'q' EmptyB)) 'b' (NodeB (NodeB EmptyB 'e' EmptyB) 'f' (NodeB EmptyB 'p' EmptyB)))
                'w'
                (NodeB (NodeB EmptyB 'r' EmptyB) 'a' (NodeB (NodeB EmptyB 'k' EmptyB) 'u'  (NodeB EmptyB 'd' EmptyB)))

ejemploI:: TreeB Int
ejemploI= NodeB (NodeB (NodeB (NodeB EmptyB 3 EmptyB) 6 (NodeB EmptyB 8 EmptyB)) 4 (NodeB (NodeB EmptyB 7 EmptyB) 5 (NodeB EmptyB 10 EmptyB)))
                6
                (NodeB (NodeB EmptyB 2 EmptyB) 5 (NodeB (NodeB EmptyB 9 EmptyB) 4 (NodeB EmptyB 7 EmptyB)))

suma :: TreeB Int -> Int
suma EmptyB = 0
suma (NodeB i v d) = suma i + v + suma d

prof:: TreeB a -> Int
prof EmptyB = 0
prof (NodeB lt x rt) = 1 + max (prof lt) (prof rt)

anotaProf :: TreeB a -> TreeB (a, Int) 
anotaProf EmptyB = EmptyB
anotaProf (NodeB lt x rt) = NodeB lt' (x, 1 + max (verProf lt') (verProf rt')) rt'
    where
        lt' = anotaProf lt
        rt' = anotaProf rt
        verProf EmptyB = 0
        verProf (NodeB _ (_,p) _) = p

anotaSumProf :: TreeB Int -> TreeB (Int, Int, Int) 
anotaSumProf EmptyB = EmptyB
anotaSumProf (NodeB lt x rt) = 
    NodeB lt' (x, x+verSum lt' + verSum rt', 1+max (verProf lt') (verProf rt')) rt'
    where
        lt' = anotaSumProf lt
        rt' = anotaSumProf rt
        verSum EmptyB = 0
        verSum (NodeB _ (_,s,_) _) = s
        verProf EmptyB = 0
        verProf (NodeB _ (_,_,p) _) = p

atLevelB :: Int -> TreeB a -> [a]
atLevelB _ EmptyB          = []
atLevelB 0 (NodeB lt x rt) = [x]
atLevelB n (NodeB lt x rt) = atLevelB (n-1) lt ++ atLevelB (n-1) rt

pathsToB :: (Eq a) => a -> TreeB a -> [[a]]
pathsToB x EmptyB = []
pathsToB x (NodeB lt y rt) 
    | x==y           = [y] : ps 
    | otherwise      = ps
   where
    ps = map (y:) (pathsToB x lt ++ pathsToB x rt)

preOrderB :: TreeB a -> [a]
preOrderB EmptyB = []
preOrderB (NodeB lt x rt) = preOrderB lt ++ [x] ++ preOrderB rt

inOrderB :: TreeB a -> [a]
inOrderB EmptyB = []
inOrderB (NodeB lt x rt) = [x] ++ inOrderB lt ++ inOrderB rt 

postOrderB EmptyB = []
postOrderB (NodeB lt x rt) = postOrderB lt ++ postOrderB rt ++ [x]